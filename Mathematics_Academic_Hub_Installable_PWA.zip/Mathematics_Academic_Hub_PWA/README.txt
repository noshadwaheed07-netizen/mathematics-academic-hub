MATHEMATICS ACADEMIC HUB — INSTALLABLE WEB APP

Files:
- index.html: app interface
- manifest.webmanifest: install metadata
- sw.js: offline app-shell cache
- icons/: app icons

IMPORTANT:
A Progressive Web App must be served from HTTPS (or localhost) for installation and
service-worker/offline support. Opening index.html directly from a file manager will
show the dashboard, but the browser may not offer full PWA installation.

Easiest publishing route:
1. Create a GitHub repository.
2. Upload the CONTENTS of this folder (index.html, manifest.webmanifest, sw.js, icons/).
3. In repository Settings > Pages, publish from the main branch and root folder.
4. Open the resulting HTTPS GitHub Pages address in Chrome on Android.
5. Use Install app / Add to Home screen.

Your academic records are stored locally in that browser. Export JSON backups regularly.
This app does not connect to IBA CMS or Google Calendar.
